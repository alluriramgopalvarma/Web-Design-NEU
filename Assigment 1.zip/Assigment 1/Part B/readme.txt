Name: Ram Gopal Varma
NUID: 002196886

Assignment:
Create 2 pages website for a coffee shop or Travel or anything with a Usage of a minimum of 5-6 HTML5 tags like audio, video, header, footer, etc.

Description:
Used HTML5 tags to create a travel guide website for touring in boston

The page consists of three pages in total
1. Home Page
2. Travel Page (Cool Things to do)
3. Contac Us Page

HTML5 Tags Used:
<header>
<nav>
<section>
<video>
<audio>
<source>
<article>
<aside>
<footer>
<b>
<img>
<div>
<title>
