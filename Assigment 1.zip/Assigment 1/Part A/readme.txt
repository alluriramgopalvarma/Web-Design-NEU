Name: Ram Gopal Varma
NUID: 002196886

Assignment:
Create 2 pages website for a coffee shop,Travel or anything by using of below HTML controls and feel free to add more HTML controls

1. Favicon
2. Table
3. Form
4. Images
5. Hyperlink
6. Button etc.

Description:
Used Favicon, Table, Form, Images, Hyperlink and Button tags to create a coffee shop/café website

The page consists of three pages in total
1. Home Page
2. Menu Page
3. Contact Page

HTML5 Tags Used:
<header>
<nav>
<div>
<table>
<label>
<input>
<img>
<form>
<a>
<button>
<link>